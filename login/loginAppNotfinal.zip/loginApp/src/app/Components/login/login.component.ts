import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from 'src/app/Service/login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  credential = {
    email: "",
    password: ""
  }
  token: string="";
  constructor(private loginService: LoginService, private router:Router) { }

  ngOnInit(): void {
  }

  onSubmit() {
    console.log("form submitted")
    if ((this.credential.email != "" && this.credential.password != "") && (this.credential.password != null && this.credential.email != null)) {
      console.log("now subit to backend")
      this.loginService.generateToken(this.credential).subscribe(
        response => {
          this.loginService.loginUser(response.jwtToken);
          console.log("------------------------------------------------------------")
          this.loginService.getUserByEmail(this.credential.email).subscribe(
            data =>{
              localStorage.setItem("userDetails",JSON.stringify(data));
              localStorage.setItem("userEmail",data.email);
              localStorage.setItem("userId",data.userId);
             // window.location.href = "/dashboard";
              this.router.navigate(["dashboard"]);
              console.log("logged in");
            },error =>
            {
              console.log(error);
            }
          )
        },
        error => {
          console.log(error);
        }
        
      )

    } else {
      console.log("fields are empty")
    }
  }
}
