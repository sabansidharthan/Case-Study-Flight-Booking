import { Component, OnInit } from '@angular/core';
import { SignupService } from 'src/app/Service/signup.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  user={
    userId:"",
    userName:"",
    email:"",
    phoneNumber:"",
    password:""
  }
  
  constructor(private signupService: SignupService) { }

  ngOnInit(): void {
  }

  onSubmitSignup(){
    console.log("form submitted")
    if((this.user.userName!="" && this.user.password!="")&&(this.user.password!=null && this.user.userName!=null)&&(this.user.email!=null && this.user.email!=null)){
      console.log("now subit to backend")
      console.log(this.user)
     
      this.signupService.addUser(this.user).subscribe(
        (data)=>{
          console.log(data);
          alert('Succesfully Registered');
        },
        (error)=>{
          console.log(error);
        }
        
      )
      alert('Succesfully Registered');
    }else{
      console.log("fields are empty")
    }
  }

}
