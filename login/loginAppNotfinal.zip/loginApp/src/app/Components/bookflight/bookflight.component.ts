import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { Booking } from 'src/app/Model/booking';
import { LoginService } from 'src/app/Service/login.service';

interface Gender {
  value: string;
  viewValue: string;
}

@Component({
  selector: 'app-bookflight',
  templateUrl: './bookflight.component.html',
  styleUrls: ['./bookflight.component.css']
})
export class BookflightComponent implements OnInit {
  addBookingForm!: FormGroup;

  gender: Gender[] = [
    {value:"", viewValue:"Gender"},
    { value: 'male', viewValue: 'MALE' },
    { value: 'female', viewValue: 'FEMALE' },
    { value: 'other', viewValue: 'OTHER' }
  ];

  isLoggedIn = false;
  reservedSource: string = "";
  reservedDestination: string = "";
  reservedDepartDate: string = "";
  reservedFlightNumber: string = "";

  booking!: Booking;
  reserve={
    bookingId:"",
    userEmail:"",
    firstName:"",
    lastName:"",
    passengerEmail:"",
    passengerPhone:"",
    passengerAge:0,
    gender:"",
    bookingDate: Date,
    flightId: 0
  }
  constructor(
     private loginService: LoginService,
     private router: Router, 
     private fb:FormBuilder,
     private route: ActivatedRoute) { }
  ngOnInit(): void {

    this.isLoggedIn = !!this.loginService.isLoggedIn();
    //check if logged in else error
    if (this.isLoggedIn) {
      this.route.paramMap.subscribe((params: ParamMap) => {
        let source = params.get('source') || "";
        this.reservedSource = source;
        let destination = params.get('destination') || "";
        this.reservedDestination = destination;
        let departDate = params.get('departDate') || "";
        this.reservedDepartDate = departDate;
        let flightNumber = params.get('flightNumber') || "";
        this.reservedFlightNumber = flightNumber;
      })}

          //form group
          this.addBookingForm = this.fb.group({
            firstName:['',[Validators.required]]!,
            lastName:['',[Validators.required]]!,
            passengerEmail:['',[Validators.required]]!,
            passengerPhone:['',[Validators.required]]!,
            passengerAge:new FormControl()!,
            gender:new FormControl()!
          })

    
  }

  
  get selectgender(){
    return this.addBookingForm.get('gender')!;
  }
  
  

  onSubmitSignup(){
    alert("submit");
    console.log(this.reserve+"hellooo");
    console.log(this.addBookingForm.controls['gender'].value);
    
  }
  

}


