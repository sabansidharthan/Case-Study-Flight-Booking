import { FlightInt } from "./flight-int";

export interface FlightList {

    flightlist:Array<FlightInt>
}
