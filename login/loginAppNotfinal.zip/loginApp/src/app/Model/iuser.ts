export interface Iuser {
    userId:string;
    userName:string;
    email:string;
    phoneNumber:string;
    password:string;
}
