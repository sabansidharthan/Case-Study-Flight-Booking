export class Flight {   

    flightNumber!: Number;
    source!: String;
    departDate!: Date;
    departTime!: Date;
    destination!: String;
    arrivalDate!: Date;
    arrivalTime!: Date;
    travelTime!: Number;
    fare!: Number;
    seatsRemaining!: Number;

    // constructor(flightNumber: Number,
    //     source: String,
    //     departDate: Date,
    //     departTime: Date,
    //     destination: String,
    //     arrivalDate: Date,
    //     arrivalTime: Date,
    //     travelTime: Number,
    //     fare: Number,
    //     seatsRemaining: Number) {}
}
        // this.flightNumber = flightNumber;
        // this.source = source;
        // this.departDate = departDate;
        // this.departTime = departTime;
        // this.destination = destination;
        // this.arrivalDate = arrivalDate;
        // this.arrivalTime = arrivalTime;
        // this.travelTime = travelTime;
        // this.fare = fare;
        // this.seatsRemaining = seatsRemaining;

    