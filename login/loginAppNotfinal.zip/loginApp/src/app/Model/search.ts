export class Search {
    source!: string;
    destination!: string;
}
